// Entorno jsdom + globals de red de Node (jsdom no los trae y msw los necesita).
const { TestEnvironment } = require('jest-environment-jsdom');

class JsdomWithFetchEnvironment extends TestEnvironment {
  constructor(config, context) {
    super(config, context);
    const g = this.global;
    const names = [
      'fetch', 'Request', 'Response', 'Headers', 'FormData', 'Blob', 'File',
      'ReadableStream', 'WritableStream', 'TransformStream',
      'TextEncoder', 'TextDecoder', 'BroadcastChannel', 'MessageChannel',
      'AbortController', 'AbortSignal', 'Event', 'EventTarget', 'structuredClone',
    ];
    g.setImmediate = setImmediate;
    g.clearImmediate = clearImmediate;
    for (const n of names) {
      if (typeof globalThis[n] !== 'undefined' && (n === 'fetch' || typeof g[n] === 'undefined' || ['Event','EventTarget','AbortController','AbortSignal','Blob','File','FormData'].indexOf(n) === -1)) {
        g[n] = globalThis[n];
      }
    }
  }
}
module.exports = JsdomWithFetchEnvironment;
