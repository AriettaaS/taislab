import { jest } from '@jest/globals';
import { http, HttpResponse } from 'msw';
import { server } from '../../mocks/server';
import { GeocodingService } from '../../services/GeocodingService';

const GEO_URL = 'https://geocoding-api.open-meteo.com/v1/search';

describe('GeocodingService', () => {
  let service: GeocodingService;

  beforeEach(() => {
    service = new GeocodingService();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('isValidCityName', () => {
    it('acepta un nombre de ciudad normal', () => {
      expect(service.isValidCityName('Madrid')).toBe(true);
    });

    it('acepta nombres con espacios internos y acentos', () => {
      expect(service.isValidCityName('São Paulo')).toBe(true);
      expect(service.isValidCityName('San Cristóbal de La Laguna')).toBe(true);
    });

    it('rechaza cadena vacía', () => {
      expect(service.isValidCityName('')).toBe(false);
    });

    it('rechaza cadena de solo espacios, tabs o saltos de línea', () => {
      expect(service.isValidCityName('   ')).toBe(false);
      expect(service.isValidCityName('\t\n ')).toBe(false);
    });

    it('acepta un nombre con espacios alrededor', () => {
      expect(service.isValidCityName('  Lima  ')).toBe(true);
    });
  });

  describe('getCoordinates - casos exitosos', () => {
    it('devuelve las coordenadas de Madrid', async () => {
      const result = await service.getCoordinates('Madrid');
      expect(result).toEqual({
        name: 'Madrid',
        latitude: 40.4165,
        longitude: -3.7026,
        country: 'Spain',
        country_code: 'ES',
      });
    });

    it('no distingue mayúsculas/minúsculas (según el mock)', async () => {
      const result = await service.getCoordinates('MADRID');
      expect(result.country_code).toBe('ES');
    });

    it('devuelve solo los 5 campos del contrato y descarta campos extra', async () => {
      server.use(
        http.get(GEO_URL, () =>
          HttpResponse.json({
            results: [
              {
                name: 'Arequipa',
                latitude: -16.4,
                longitude: -71.5,
                country: 'Peru',
                country_code: 'PE',
                elevation: 2335,
                population: 1000000,
                timezone: 'America/Lima',
              },
            ],
          }),
        ),
      );
      const result = await service.getCoordinates('Arequipa');
      expect(Object.keys(result).sort()).toEqual(
        ['country', 'country_code', 'latitude', 'longitude', 'name'],
      );
    });

    it('usa solo el primer resultado cuando la API devuelve varios', async () => {
      server.use(
        http.get(GEO_URL, () =>
          HttpResponse.json({
            results: [
              { name: 'Springfield', latitude: 1, longitude: 2, country: 'USA', country_code: 'US' },
              { name: 'Springfield', latitude: 3, longitude: 4, country: 'Canada', country_code: 'CA' },
            ],
          }),
        ),
      );
      const result = await service.getCoordinates('Springfield');
      expect(result.country_code).toBe('US');
      expect(result.latitude).toBe(1);
    });

    it('para ciudades no especiales usa la respuesta por defecto del mock', async () => {
      const result = await service.getCoordinates('Lima');
      expect(result.name).toBe('Lima');
      expect(result.country_code).toBe('DC');
    });
  });

  describe('getCoordinates - construcción de la petición', () => {
    it('envía los parámetros name y count=1', async () => {
      let captured: URL | undefined;
      server.use(
        http.get(GEO_URL, ({ request }) => {
          captured = new URL(request.url);
          return HttpResponse.json({
            results: [{ name: 'X', latitude: 0, longitude: 0, country: 'C', country_code: 'CC' }],
          });
        }),
      );
      await service.getCoordinates('Cusco');
      expect(captured?.searchParams.get('name')).toBe('Cusco');
      expect(captured?.searchParams.get('count')).toBe('1');
    });

    it('codifica correctamente caracteres especiales en la URL', async () => {
      let captured: URL | undefined;
      server.use(
        http.get(GEO_URL, ({ request }) => {
          captured = new URL(request.url);
          return HttpResponse.json({
            results: [{ name: 'X', latitude: 0, longitude: 0, country: 'C', country_code: 'CC' }],
          });
        }),
      );
      await service.getCoordinates('São Paulo & Co');
      expect(captured?.searchParams.get('name')).toBe('São Paulo & Co');
      expect(captured?.search).not.toContain('& Co');
    });

    it('llama a fetch exactamente una vez', async () => {
      const spy = jest.spyOn(globalThis, 'fetch');
      await service.getCoordinates('Madrid');
      expect(spy).toHaveBeenCalledTimes(1);
    });

    it('NO recorta (trim) el nombre antes de enviarlo (comportamiento actual)', async () => {
      let sent: string | null = null;
      server.use(
        http.get(GEO_URL, ({ request }) => {
          sent = new URL(request.url).searchParams.get('name');
          return HttpResponse.json({
            results: [{ name: 'X', latitude: 0, longitude: 0, country: 'C', country_code: 'CC' }],
          });
        }),
      );
      await service.getCoordinates('  Madrid  ');
      expect(sent).toBe('  Madrid  ');
    });
  });

  describe('getCoordinates - validación de entrada', () => {
    it('lanza error si el nombre está vacío', async () => {
      await expect(service.getCoordinates('')).rejects.toThrow(
        'El nombre de la ciudad no puede estar vacío',
      );
    });

    it('lanza error si el nombre son solo espacios', async () => {
      await expect(service.getCoordinates('    ')).rejects.toThrow(
        'El nombre de la ciudad no puede estar vacío',
      );
    });

    it('no hace ninguna petición HTTP si la entrada es inválida', async () => {
      const spy = jest.spyOn(globalThis, 'fetch');
      await expect(service.getCoordinates('')).rejects.toThrow();
      expect(spy).not.toHaveBeenCalled();
    });

    it('el error de validación NO se envuelve con "Error al obtener coordenadas"', async () => {
      await expect(service.getCoordinates(' ')).rejects.toThrow(
        /^El nombre de la ciudad no puede estar vacío$/,
      );
    });
  });

  describe('getCoordinates - errores de la API', () => {
    it('lanza error cuando la ciudad no existe (results vacío)', async () => {
      await expect(service.getCoordinates('ciudad no encontrada')).rejects.toThrow(
        /Ciudad no encontrada: "ciudad no encontrada"/,
      );
    });

    it('lanza error cuando la respuesta no trae la propiedad results', async () => {
      server.use(http.get(GEO_URL, () => HttpResponse.json({})));
      await expect(service.getCoordinates('Nada')).rejects.toThrow(/Ciudad no encontrada: "Nada"/);
    });

    it('lanza error con el código HTTP cuando la API responde 500', async () => {
      server.use(
        http.get(GEO_URL, () => new HttpResponse(null, { status: 500, statusText: 'Internal Server Error' })),
      );
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(/Error de geocodificación: 500/);
    });

    it('lanza error con el código HTTP cuando la API responde 404', async () => {
      server.use(http.get(GEO_URL, () => new HttpResponse(null, { status: 404 })));
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(/404/);
    });

    it('lanza error con 429 (rate limit)', async () => {
      server.use(http.get(GEO_URL, () => new HttpResponse(null, { status: 429 })));
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(/429/);
    });

    it('envuelve los errores internos con el prefijo "Error al obtener coordenadas"', async () => {
      server.use(http.get(GEO_URL, () => new HttpResponse(null, { status: 500 })));
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(
        /^Error al obtener coordenadas: /,
      );
    });

    it('DOBLE envoltura: "ciudad no encontrada" queda prefijada dos veces (comportamiento actual)', async () => {
      await expect(service.getCoordinates('ciudad no encontrada')).rejects.toThrow(
        /^Error al obtener coordenadas: Ciudad no encontrada: "ciudad no encontrada"$/,
      );
    });

    it('lanza error si hay fallo de red', async () => {
      server.use(http.get(GEO_URL, () => HttpResponse.error()));
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(
        /Error al obtener coordenadas/,
      );
    });

    it('lanza error si la respuesta no es JSON válido', async () => {
      server.use(
        http.get(GEO_URL, () => new HttpResponse('<html>no es json</html>', { status: 200 })),
      );
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(
        /Error al obtener coordenadas/,
      );
    });

    it('lanza "Error desconocido" cuando se rechaza con un valor que no es Error', async () => {
      jest.spyOn(globalThis, 'fetch').mockRejectedValueOnce('boom');
      await expect(service.getCoordinates('Madrid')).rejects.toThrow(
        'Error desconocido al obtener coordenadas',
      );
    });

    it('devuelve el error como instancia de Error', async () => {
      server.use(http.get(GEO_URL, () => new HttpResponse(null, { status: 500 })));
      await expect(service.getCoordinates('Madrid')).rejects.toBeInstanceOf(Error);
    });
  });

  describe('instancias independientes', () => {
    it('dos instancias funcionan de forma independiente', async () => {
      const a = new GeocodingService();
      const b = new GeocodingService();
      const [ra, rb] = await Promise.all([a.getCoordinates('Madrid'), b.getCoordinates('Lima')]);
      expect(ra.name).toBe('Madrid');
      expect(rb.name).toBe('Lima');
    });
  });
});
