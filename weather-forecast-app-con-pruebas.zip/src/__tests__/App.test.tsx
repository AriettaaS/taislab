import { render, screen } from '@testing-library/react';
import App from '../App';

describe('App', () => {
  it('se renderiza sin errores', () => {
    const { container } = render(<App />);
    expect(container.firstChild).toBeInTheDocument();
  });

  it('muestra el título principal como encabezado h1', () => {
    render(<App />);
    expect(
      screen.getByRole('heading', { level: 1, name: 'Aplicación de Pronóstico del Clima' }),
    ).toBeInTheDocument();
  });

  it('muestra las instrucciones para el usuario', () => {
    render(<App />);
    expect(
      screen.getByText(/Ingresa el nombre de una ciudad para obtener el pronóstico del tiempo/),
    ).toBeInTheDocument();
  });

  it('muestra el mensaje de desarrollo en progreso', () => {
    render(<App />);
    expect(screen.getByText('Desarrollo en progreso...')).toBeInTheDocument();
  });

  it('tiene un único encabezado', () => {
    render(<App />);
    expect(screen.getAllByRole('heading')).toHaveLength(1);
  });

  it('aplica las clases de Tailwind del contenedor principal', () => {
    const { container } = render(<App />);
    expect(container.firstChild).toHaveClass('min-h-screen', 'flex', 'items-center');
  });

  it('(pendiente) aún no ofrece campo de búsqueda de ciudad', () => {
    render(<App />);
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument();
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('coincide con el snapshot estructural', () => {
    const { container } = render(<App />);
    expect(container).toMatchSnapshot();
  });
});
