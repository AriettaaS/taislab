import { server } from '../../mocks/server';
import { handlers } from '../../mocks/handlers';

describe('MSW handlers (contrato de la API simulada)', () => {
  it('define un handler por cada endpoint (geocoding + forecast)', () => {
    expect(handlers).toHaveLength(2);
  });

  it('el servidor MSW está inicializado', () => {
    expect(server).toBeDefined();
    expect(typeof server.listen).toBe('function');
  });

  describe('Open-Meteo forecast', () => {
    const url = 'https://api.open-meteo.com/v1/forecast?latitude=40.4&longitude=-3.7';

    it('responde 200 con JSON', async () => {
      const res = await fetch(url);
      expect(res.status).toBe(200);
      expect(res.headers.get('content-type')).toContain('application/json');
    });

    it('devuelve 7 días con arrays de igual longitud', async () => {
      const { daily } = await (await fetch(url)).json();
      const len = daily.time.length;
      expect(len).toBe(7);
      expect(daily.temperature_2m_max).toHaveLength(len);
      expect(daily.temperature_2m_min).toHaveLength(len);
      expect(daily.relative_humidity_2m_mean).toHaveLength(len);
      expect(daily.precipitation_sum).toHaveLength(len);
    });

    it('la temperatura máxima es siempre mayor que la mínima', async () => {
      const { daily } = await (await fetch(url)).json();
      daily.temperature_2m_max.forEach((max: number, i: number) => {
        expect(max).toBeGreaterThan(daily.temperature_2m_min[i]);
      });
    });

    it('la humedad está entre 0 y 100 y la precipitación no es negativa', async () => {
      const { daily } = await (await fetch(url)).json();
      daily.relative_humidity_2m_mean.forEach((h: number) => {
        expect(h).toBeGreaterThanOrEqual(0);
        expect(h).toBeLessThanOrEqual(100);
      });
      daily.precipitation_sum.forEach((p: number) => expect(p).toBeGreaterThanOrEqual(0));
    });

    it('incluye las unidades diarias', async () => {
      const { daily_units } = await (await fetch(url)).json();
      expect(daily_units.temperature_2m_max).toBe('°C');
      expect(daily_units.relative_humidity_2m_mean).toBe('%');
      expect(daily_units.precipitation_sum).toBe('mm');
    });

    it('las fechas tienen formato ISO YYYY-MM-DD', async () => {
      const { daily } = await (await fetch(url)).json();
      daily.time.forEach((d: string) => expect(d).toMatch(/^\d{4}-\d{2}-\d{2}$/));
    });
  });

  describe('configuración de seguridad de pruebas', () => {
    it('rechaza peticiones a URLs no mockeadas (onUnhandledFrame: error)', async () => {
      // Se comprueba la causa para asegurar que el rechazo lo provoca MSW
      // y no simplemente la falta de red.
      const error = await fetch('https://example.com/no-mockeado').catch((e: unknown) => e);
      expect(String((error as { cause?: { message?: string } }).cause?.message)).toContain(
        'onUnhandledFrame',
      );
    });
  });
});
