import '@testing-library/jest-dom';
import { jest } from '@jest/globals';
import { server } from './mocks/server';

// Establecer el tiempo de espera global para pruebas
jest.setTimeout(10000);

// Configurar MSW para interceptar solicitudes HTTP
beforeAll(() => server.listen({ onUnhandledFrame: 'error' }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
