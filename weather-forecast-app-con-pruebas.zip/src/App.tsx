﻿import React from 'react';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="max-w-4xl w-full bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-6">
          Aplicación de Pronóstico del Clima
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Ingresa el nombre de una ciudad para obtener el pronóstico del tiempo
        </p>
        <div className="text-center">
          <p className="text-gray-500">
            Desarrollo en progreso...
          </p>
        </div>
      </div>
    </div>
  );
};

export default App;
